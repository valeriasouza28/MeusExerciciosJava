package org.example;

import javax.swing.*;

public class TelaValores {
    private JTextField txtNum;
    private JTextField txtDen;
    private JButton btnDividir;
    private JLabel lblDiv;
    private JLabel lblResto;
}
