# introJUnit
## Introdução à utilização do JUnit para o desenvolvimento de testes. 
## Utilizamos a versão 5 do framework para este exemplo.

  
