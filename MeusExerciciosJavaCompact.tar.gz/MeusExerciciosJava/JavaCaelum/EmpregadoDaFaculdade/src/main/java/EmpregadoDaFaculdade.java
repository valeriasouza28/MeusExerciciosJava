public class EmpregadoDaFaculdade {

    private String nome;
    private double salario;
    public double getGastos() {
        return this.salario;
    }

    public String getInfo() {
        return "nome: " + this.nome + " Com salário " + this.salario;
    }
    public void setNome(String nome){
        this.nome = nome;
    }

    public String getNome(){
        return nome;
    }
    public void setSalario (int salario){
        this.salario = salario;
    }

    public double getSalario(){
        return salario;
    }

}
