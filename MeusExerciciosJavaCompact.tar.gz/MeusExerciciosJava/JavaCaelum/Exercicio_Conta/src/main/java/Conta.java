public class Conta {

    String titular;
    int numero;
    String agencia;
    double saldo;
    String dataAbertura;

    void saca(){

    }
    void deposita(){

    }

    void calculaRendimento() {

    }
}
