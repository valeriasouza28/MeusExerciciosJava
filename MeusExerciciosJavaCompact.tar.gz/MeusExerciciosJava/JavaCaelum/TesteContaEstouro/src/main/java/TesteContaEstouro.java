public class TesteContaEstouro {
    public static void main(String[] args) {

        /*Testa Estouro 3*/

        //A conta
        Conta minhaConta = new Conta();
        minhaConta.saldo = 100;

        //quero mudar o saldo da conta para -200
        double novoSaldo = -200;

        //testa se novo saldo é válido
        if (novosaldo < 0) {
            System.out.println("Não posso mudar para esse saldo");
        } else {
            minhaConta.saldo = novoSaldo;
        }

    }//fim do método main
}
    /*TestaContaEstouro2

Conta minhaConta = new Conta();
minhaConta.saldo = -200; //saldo está abaixo de 0

    * */

    /* TestaConta Estouro 1

        Conta minhaConta = new Conta();
        minhaConta.saldo = -1000.0;
         minhaConta.saca(50000)//saldo é só 1000
     */

}//fim da classe TestaContaTestaEstouro
