class Cliente {
        private String nome;
        private String endereco;
        private String cpf;
        private int idade;



        public void mudaCPF(String cpf){

                if (this.idade <= 60) {
                        validaCPF(cpf);
                }
                this.cpf = cpf;

        }

        private void validaCPF(String cpf) {

                //série de regras aqui falha caso não seja válida.
        }

        // ..
}

class Conta {
        private int numero;
        private String titular;
        private double saldo;
        private double limite;
        public Conta(){

                this.numero = numero;
                this.titular = titular;
                this.saldo = saldo;
                this.limite = limite;
        }

        public double pegaSaldo(){
                return this.saldo;
        }


        public void saca(double valor) {

                //posso sacar até saldo
                if (this.saldo > valor) {
                        System.out.println("Não possso sacar um valor maior do que o saldo!");
        }// fim do if
        else {
        this.saldo = this.saldo - valor;
        }// fim do else
        }//fim do método saca

        void deposita(double quantidade) {

        this.saldo += quantidade;
        }

        boolean transfere(Conta destino, double valor){

        boolean retirou = this.saca(valor);
        if(retirou == false){
        //não deu para sacar!
        return false;
        }
        else{
        destino.deposita(valor);
        return true;
        }
        }
        }