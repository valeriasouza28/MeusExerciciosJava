public class TestaAlgunsMetodos {

    public static void main(String[] args) {
        //criando a conta
        Conta minhaConta;
        minhaConta = new Conta();

        //alterando os valore de minhaConta
//        minhaConta.titular = "Duke";
//        minhaConta.saldo = 1000;

        //saca 200 reais
//        minhaConta.saca(200);

        // deposita 500 reais
//        minhaConta.deposita(500);
//        System.out.println(minhaConta.saldo);

        // exemplo de uso do método saca retornado boolean
        minhaConta.saldo = 1000;
        boolean consegui = minhaConta.saca(2000);
        if (consegui) {
            System.out.println("Consegui sacar");
        } else {
            System.out.println("Não consegui sacar");
        }//fim do else
    }//fim do método main/
}//fim da classe Testa alguns métodos

class Conta{

    int numero;
    String titular;
    double saldo;
    double limite;

    public Conta(){
        this.numero = numero;
        this.titular = titular;
        this.saldo = saldo;
        this.limite = limite;
    }

    boolean saca(double valor) {

        if(this.saldo< valor){
            return false;
        }// fim do if
        else{
        this.saldo = this.saldo - valor;
        return true;
    }// fim do else
    }//fim do método saca

    void deposita( double quantidade){

        this.saldo += quantidade;
    }
}
