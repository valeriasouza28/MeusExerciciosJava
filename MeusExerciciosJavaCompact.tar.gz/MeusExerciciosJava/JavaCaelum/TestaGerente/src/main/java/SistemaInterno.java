import java.util.Scanner;

public class SistemaInterno {

    Scanner sc = new Scanner(System.in);

    public void login( Autenticavel a){

        int senha = sc.nextInt();

        //Aqui eu posso chamar o método autentica!
        //Pois, todo FuncionarioAuntenticavel o tem.

        boolean ok = a.autentica(senha);
        
    }
}
