public class Diretor extends Funcionario implements Autenticavel{

    private int senha;
    // implementa método abstrato da classe abstrata Funcionario

    public boolean autentica(int senha){
        if (this.senha != senha){
            System.out.println("Aceesso perrmitido");
        }
        return true;
    }
    public double getBonificacao(){
        System.out.println("Não possui Bonificação!");
        double bonificacaoDiretor = 0;
        return bonificacaoDiretor;
    }
    public void  setSenha(int senha){
        this.senha = senha;
    }
    public int getSenha(){
        return senha;
    }

    public boolean autentica(int senha){
        if (this.senha == senha){
            System.out.println("Acesso permitido!");
            return true;
        }
        else {
            System.out.println("Acesso Negado!");
            return false;
        }
    }

}
