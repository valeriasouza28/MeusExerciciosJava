public  abstract class Funcionario {

    protected String nome;
    protected String cpf;
    protected double salario;
    //métodos devem vir aqui

    public void setNome(String nome){

        this.nome = nome;

    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public double getSalario(){
        return salario;
    }

    public abstract double getBonificacao();
}

class ControleDeBonificacoes {
    private double totalDeBonificacoes = 0;

    public void registra(Funcionario f) {

        System.out.println("Adicionando bonificacao do funcionario: " + f);
        this.totalDeBonificacoes += f.getBonificacao();
    }

    public double getTotalDeBonificacoes() {
        return this.totalDeBonificacoes;
    }
}
