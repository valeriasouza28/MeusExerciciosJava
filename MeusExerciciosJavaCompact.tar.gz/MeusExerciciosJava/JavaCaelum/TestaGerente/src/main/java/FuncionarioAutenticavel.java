public class FuncionarioAutenticavel extends Funcionario{

    public double getBonificacao(){
        System.out.println("Não possui Bonificação, Não é Funcionario!");
        double bonificacaoAutenticacao = 0;
        return bonificacaoAutenticacao;
    }
    private int senha;

        public boolean autentica(int senha){
            if (this.senha == senha){
                System.out.println("Acesso permitido!");
                return true;
            }
            else {
                System.out.println("Acesso Negado!");
                return false;
            }
        }


}
