public class Gerente extends Funcionario implements Autenticavel{


    private int senha;
    private int numeroDeFuncionariosGerenciados;

    private Gerente gerente;




    public void setSenha(int senha,Gerente gerente){

        this.senha = senha;
    }

    public boolean autentica(int senha) {
        if (this.senha != senha) {
            System.out.println("Acesso Negado!");
        System.out.println("Seu departamento não tem acesso.");
        return false;
    } else  {
            System.out.println("Acesso permitido!");
            System.out.println("Seu departamento tem Acesso.");
        }
        if()
        return true;
        }




    @Override
    public double getBonificacao(){
        return getBonificacao() * 1.4 + 1000;
    }


}
