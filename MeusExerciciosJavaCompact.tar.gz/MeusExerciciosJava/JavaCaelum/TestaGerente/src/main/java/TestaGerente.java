public class TestaGerente {

    public static void main(String[] args) {

        Autenticavel a = new Gerente();


        /* Gerente g1 = new Gerente();
        g1.setSenha(12345);
        g1.autentica(12345);*/


    }
}
