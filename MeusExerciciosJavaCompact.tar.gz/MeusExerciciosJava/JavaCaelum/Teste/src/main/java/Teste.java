public class Teste {

    public static void main(String[] args) {

        Conta minhaConta = new Conta();

        minhaConta.titular.nome = "Manoel";
        //...

        //...
    }//fim do método main
}//fim da classe Teste

class Cliente{
    String nome;
    String sobrenome;
    String cpf;
}

class Conta {
    int numero;
    double saldo;

    Cliente titular = new Cliente(); // quando chamar new Conta,
                                    //haverá um new Cliente para ele.

}
