public class TestaReferencias {

    public static void main(String[] args) {

        Conta c1 = new Conta();
        c1.titular = "Duke";
        c1.saldo = 227;

        Conta c2 = new Conta();
        c2.titular = "Duke";
        c2.saldo = 227;

        if ( c1 == c2 ){
            System.out.println("Contas iguais");
        }

        /*Conta c1 = new Conta();
        c1.deposita(100);

        Conta c2 = c1; //linha importante
        c2.deposita(200);

        System.out.println(c1.saldo);
        System.out.println(c2.saldo);*/

    }
}

class Conta {

    int numero;
    String titular;
    double saldo;
    double limite;

    public Conta() {
        this.numero = numero;
        this.titular = titular;
        this.saldo = saldo;
        this.limite = limite;
    }

    boolean saca(double valor) {

        if (this.saldo < valor) {
            return false;
        }// fim do if
        else {
            this.saldo = this.saldo - valor;
            return true;
        }// fim do else
    }//fim do método saca

    void deposita(double quantidade) {

        this.saldo += quantidade;
    }

    boolean transfere(Conta destino, double valor){

        boolean retirou = this.saca(valor);
        if(retirou == false){
            //não deu para sacar!
            return false;
        }
        else{
            destino.deposita(valor);
            return true;
        }
    }
}


