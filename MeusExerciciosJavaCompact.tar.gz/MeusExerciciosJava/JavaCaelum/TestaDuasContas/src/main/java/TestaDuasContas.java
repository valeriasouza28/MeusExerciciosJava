public class TestaDuasContas {

    public static void main(String[] args) {

       Conta c1;
       c1 = new Conta();

       Conta c2;
       c2 = new Conta();

        /* Conta minhaConta;
        minhaConta = new Conta();
        minhaConta.saldo = 1000;

        Conta meuSonho;
        meuSonho = new Conta();
        meuSonho.saldo = 1500000;

        System.out.println("Mostra saldo de minhaConta: " + minhaConta.saldo);

        System.out.println("Mostra saldo de meuSonho: " + meuSonho.saldo);*/


    }//fim do método main
}//fim da classe TestaDuasContas


class Conta {

        int numero;
        String titular;
        double saldo;
        double limite;

        public Conta() {
            this.numero = numero;
            this.titular = titular;
            this.saldo = saldo;
            this.limite = limite;
        }

        boolean saca(double valor) {

            if (this.saldo < valor) {
                return false;
            }// fim do if
            else {
                this.saldo = this.saldo - valor;
                return true;
            }// fim do else
        }//fim do método saca

        void deposita(double quantidade) {

            this.saldo += quantidade;
        }
    }


