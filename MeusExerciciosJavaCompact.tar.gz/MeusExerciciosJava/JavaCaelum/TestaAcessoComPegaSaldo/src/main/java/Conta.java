class Conta {
    private int numero;
    private String titular;
    private double saldo;
    private double limite;
    private static int totalDeContas;



    //construtor
    public Conta(){

        System.out.println("Construindo uma Conta.");

        this.saldo = saldo;
        this.limite = limite;
        this.totalDeContas = this.totalDeContas + 1;
    }

    public int getTotalDeContas() {
        return Conta.totalDeContas;
    }
    Conta(String titular){
        // faz uma serie de inicializações e configurações
        this.titular = titular;
    }

    Conta(int numero, String titular){
        this(titular); //chama o construtor que foi declarado acima
        this.numero= numero;
    }

    public double getSaldo(){
        return this.saldo + this.limite;
    }

    public void saca(double valor) {

        //posso sacar até saldo
        if (this.saldo > valor) {
            System.out.println("Não possso sacar um valor maior do que o saldo!");
        }// fim do if
        else {
            this.saldo = this.saldo - valor;
        }// fim do else
    }//fim do método saca

    void deposita(double quantidade) {

        if (quantidade < 0 ){
            System.out.println("Não é possível fazer deposito, tente um valor positivo");
        }else {
            this.saldo += quantidade;
        }
    }

    public void transfere(Conta destino, double valor){

        //posso sacar até saldo
        if (this.saldo > valor) {
            System.out.println("Não possso transferir um valor maior do que o saldo!");
        }// fim do if
        else {
            this.saldo = this.saldo - valor;
            destino.saldo = destino.saldo + valor;
        }// fim do else

    }

    public String getTitular(){
        return  this.titular;
    }

    public void  setTitular(String titular){
        this.titular = titular;
    }
}