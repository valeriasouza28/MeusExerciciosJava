public class Gerente extends Funcionario{

    private int senha;
    private int numeroDeFuncionariosGerenciados;

    public boolean autentica(int senha){
        if (this.senha == senha){
            System.out.println("Acesso permitido!");
            return true;
        }
        else {
            System.out.println("Acesso Negado!");
            return false;
        }
    }
    //outros métodos
}
