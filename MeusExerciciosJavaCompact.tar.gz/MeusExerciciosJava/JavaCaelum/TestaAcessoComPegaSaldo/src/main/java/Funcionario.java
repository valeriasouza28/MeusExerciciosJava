public class Funcionario {

    private String nome;
    private String cpf;
    private double salario;
    //métodos devem vir aqui

}
