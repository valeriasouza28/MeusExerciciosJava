/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testecontavanessa;

//import java.text.DecimalFormat;
//import java.util.Scanner;

/**
 *
 * @author oem
 */
public class TesteContaVanessa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //DecimalFormat formato = new DecimalFormat("#.##");
        //Scanner teclado = new Scanner(System.in);
        double valorProduto = 52.10;
        double multiplicacao1 = 21.152;
        double multiplicacao2 = 15.158;
        double resultadoPorcentagem1 = valorProduto * multiplicacao1;
        double resultadoPorcentagem2 = resultadoPorcentagem1 * multiplicacao2;

        
        String formataResultado1 = Double.toString(resultadoPorcentagem1);
        System.out.println("Resultado 1: " + formataResultado1.substring(0, 7));
        
        
        //double formatado = resultadoPorcentagem2;
        String formataResultado2 = Double.toString(resultadoPorcentagem2);
        System.out.println("\nResultado 2: " + formataResultado2.substring(0, 12));
        
        
       

    }
    
}
