# Get Integer 2


A expressaõ condional na instrução `while` chama o método `hasNextInt` do 
`Scanner` para ver se o próximo valor é um 
inteiro. O loop `while` se repete enquanto 
essa chamada retornar `false`, indicando que 
o póximo valor não é um inteiro válido. 

O corpo do loop chama `nextLine` para descartar
os dados incorertos e, em seguida , exibe uma 
mensagem de erro. O loop termina apenas
quando vocẽ sabe que tem bons dados no fluxo
de entrada, portanto, a instrução `return` chama
 o `nextInt` para analisar os dados em
inteiro e retornar o valor resultante.