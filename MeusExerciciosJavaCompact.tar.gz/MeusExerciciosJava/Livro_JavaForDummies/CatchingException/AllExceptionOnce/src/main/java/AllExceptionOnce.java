import java.util.Scanner;

public class AllExceptionOnce {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter an Integer: ");
        int a = sc.nextInt();
        System.out.print("Enter an Integer: ");
        int b = sc.nextInt();
        try
        {
            int c = a / b;
            System.out.println("The result is: " + c);
        }
        catch (Exception e){
            System.out.println("Oops, you can't " + "divide by zero.");
        }

    }
}
