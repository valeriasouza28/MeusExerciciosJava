public class MyException {

    public static void main(String[] args) {

        try{
            doSomething(true);
        }

        catch(Exception  e) {

            System.out.println("Exception!");
        }
    } // fim do método main

    public static void  doSomething(boolean t)
    throws Exception {

        if(t)
            throw new Exception();
    }// fim do método
}//fim da classe MyExcption
