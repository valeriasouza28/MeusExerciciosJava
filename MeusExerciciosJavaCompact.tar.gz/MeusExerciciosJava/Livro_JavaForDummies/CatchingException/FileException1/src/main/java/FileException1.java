import java.io.*;

public class FileException1 {

    public static void main(String[] args) {
        try {
            openFile("~/Projetos_Programacao/Java/Livro_JavaForDummies/CatchingException/FileException2/test.txt");
            }//fim do try
        catch(FileNotFoundException e){
            System.out.println("File not found.");
        }

    }//fim do método main

    public static void openFile(String name)
    throws FileNotFoundException
    {
            FileInputStream f = new FileInputStream(name);

    }//fim do método openFile
}//fim da classe FileEception1
