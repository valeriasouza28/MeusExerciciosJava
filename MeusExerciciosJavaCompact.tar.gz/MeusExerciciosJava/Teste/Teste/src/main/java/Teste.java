import java.util.Scanner;

public class Teste {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Digite um número: ");
        int numero = scan.nextInt();

        if (numero % 2 == 0 ){
            System.out.println("Eh");
        }else {
            System.out.println("não");
        }
    }
}
