package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        System.out.print("Digite o nome do aluno: ");
        String nome = teclado.nextLine();
        System.out.print("Digite a nota do aluno: ");
        float nota = teclado.nextFloat();
        //System.out.printf("Sua nota de %s é %.4f \n", nome, nota);
        System.out.format("A nota de %s é %.1f \n", nome, nota);
    }
}