package org.example;

public class Main {
    public static void main(String[] args) {

        boolean a = true;
        boolean b = false;
        boolean c = false;
        System.out.println(!a);
        System.out.println(!(b || c));
    }
}