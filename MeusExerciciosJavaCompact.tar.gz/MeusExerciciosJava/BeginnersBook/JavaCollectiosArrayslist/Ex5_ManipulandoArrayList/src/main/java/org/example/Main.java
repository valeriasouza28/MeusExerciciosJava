package org.example;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        /*Criando  ArrayList do tipo 'String" que significa que
        *só podemos adicionar elementos  do tipo String*/

        ArrayList<String> obj = new ArrayList<String>();

        //Como adicionamos elemento a uma ArrayList
        obj.add("Ajeet");
        obj.add("Harry");
        obj.add("Chaitanaya");
        obj.add("Steve");
        obj.add("Anuj");

        //exibindo elementos
        System.out.println("Original ArrayList: ");
        for (String str : obj){
            System.out.println(str);
        }

        /*Adiciona elemento no índice dado
        * obj.add(0, "Rahul") - Adiciona elemento "Rahul" na primeira posição
        * obj.add(1, 'Justin") - Adicionando o elemento "Justin" na segunda posição*/
        obj.add(0, "Rahul");
        obj.add(1, "Justin");

        //Exibindo elementos
        System.out.println("ArrayList após adicionar operação: ");
        for (String str : obj) {
            System.out.println(str);
        }

        //remove elemento de ArrayList como este

        //remove "Chaitanya" de ArrayList
        obj.remove("Chaitanya");

        //Remove "Harry" de ArrayList
        obj.remove("Harry");

        //Exibindo elementos
        System.out.println("ArrayList após  operação de remoção: ");
        for (String str : obj){
            System.out.println(str);
        }

        //Remove o elemento do índice especificado

        //rmove o segundo elemento da lista
        obj.remove(1);

        //Exibindo elementos
        System.out.println("Lista de Arrays Final: ");
        for (String str : obj) {
            System.out.println(str);
        }

    }
}