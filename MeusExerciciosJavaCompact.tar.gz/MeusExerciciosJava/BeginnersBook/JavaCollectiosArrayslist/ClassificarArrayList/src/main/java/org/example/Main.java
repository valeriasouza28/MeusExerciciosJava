package org.example;

import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {

        //Criamos um ArrayList
        ArrayList<String> fruits = new ArrayList<String>();

       //Adionamos elementos a um ArrayList
        fruits.add("Orange");
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Pineapple");

        //Classificando um ArrayList
        Collections.sort(fruits);

        //Exibindo elementos
        for( String str: obj) {
            System.out.println(str);
        }


    }
}