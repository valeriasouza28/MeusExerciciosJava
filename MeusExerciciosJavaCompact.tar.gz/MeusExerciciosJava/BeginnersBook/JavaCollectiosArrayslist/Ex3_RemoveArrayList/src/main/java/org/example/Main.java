package org.example;
import java.util.ArrayList;
public class Main {
    public static void main(String[] args) {

        ArrayList<String> alist = new ArrayList<String>();
        alist.add("Steve");
        alist.add("Tim");
        alist.add("Lucy");
        alist.add("Pat");
        alist.add("Angela");
        alist.add("Tom");

        //Exibindo elementos
        System.out.println(alist);

        //removendo "Steve" e "Angela"
        alist.remove("Steve");
        alist.remove("Angela");

        //Exibindo elementos
        System.out.println(alist);

        //Removendo terceiro elemento
        alist.remove(2);

       // Exibindo elementos
        System.out.println(alist);
    }
}