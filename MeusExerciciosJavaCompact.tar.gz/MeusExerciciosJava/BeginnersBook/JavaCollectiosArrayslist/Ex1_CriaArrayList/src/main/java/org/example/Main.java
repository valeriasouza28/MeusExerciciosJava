package org.example;
import java.util.*;
public class Main {
    public static void main(String[] args) {

        ArrayList<String> alist = new ArrayList<String>();
        alist.add("Steve");
        alist.add("Tim");
        alist.add("Lucy");
        alist.add("Pat");
        alist.add("Angela");
        alist.add("Tom");

        //Exibindo elementos
        System.out.println(alist);

        //Adicionando "Steve" na quarta posição
        alist.add(3, "Steve");

        //Exibindo Elementos
        System.out.println(alist);

    }
}