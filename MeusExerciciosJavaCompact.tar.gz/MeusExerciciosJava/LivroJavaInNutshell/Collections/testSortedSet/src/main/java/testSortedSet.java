import java.awt.event.ActionEvent;
import java.util.Comparator;
import java.util.EventListener;

public  class testSortedSet {

    public static void main(String[] args) {

        public interface ActionListener extends EventListener{
            void ActionPerfomed (ActionEvent var1);

            List<Gato> meusgatos = new ArrayList<>(){{
                add.(new Gato("Jon", 12, "preto"));
                add.(new Gato("Simba", 6, "tigrado"));
                add.(new Gato("Jon", 12, "amarelo"));
            }};

            meusGatos.sort(Comparator.comparing(Gato::getNome);

        }
    }
}