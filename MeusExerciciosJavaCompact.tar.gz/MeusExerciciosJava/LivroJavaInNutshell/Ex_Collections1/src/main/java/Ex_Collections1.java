import java.util.*;

public class Ex_Collections1 {

    public static void main(String[] args) {

        Collection<String> c = new HashSet<>(); //Um conjunto vazio

        // Veremos isso métodos utilitários mais tarde. Esteja ciente de que existem
        // algumas sutilezas e cuidados ao usá-los

        Collection<String> d = Arrays.asList("one", "two");
        //O método java.util.Collections.singleton() é um método da classe java.util.Collections .
        //Ele cria um conjunto imutável sobre um único elemento especificado.
        // Uma aplicação desse método é remover um elemento de Coleções como Lista e Conjunto.
        Collection<String> e = Collections.singleton("three");
        System.out.println("mostra collection (d) " + d);
        System.out.println("mostra collection (e) " + e);

        //Adiciona elementos a uma coleção. Esses métodos retornam true
        //se a coleção mudar, o que é útil com Sets que
        // não permitem duplicatas.
        c.add("zero"); //Adiciona apena um elemento
        c.addAll(d); //Add todos os elementos em d

        //Copia uma collection: a amaioria das implementações tem um contrutor de cópia
        Collection<String> copy = new ArrayList<String>(c);

        //Remove elementos de uma coleção.
        //Todos, exceto clear, retornam true se a coleção for alterada.
        c.remove("zero"); //Remove apena um elemento
        c.removeAll(e); // Remove uma coleção de elementos
        c.retainAll(d); //Remove todos os elemenntos que  não estão em e
        c.clear(); // remove todods os elementos de uma coleção

        //Consultando o tamanho de uma coleção
        boolean b = c.isEmpty(); // c agora está vazio, true
        int s = c.size(); // O tamanho de c agora é 0

        //Restaurar coleção da cópia que fizemos
        c.addAll(copy);

        // Testa a associação na coleção. A adesão é baseada nos iguais
       // método, não o operador ==.
        b = c.contains("zero"); //true
        b = c.containsAll(d); //true

        // A maioria das implementações de coleção tem um toString() útil
        System.out.println(c);

        // Obtém um array de elementos da coleção. Se o iterador garantir
        // uma ordem, este array tem a mesma ordem. A matriz é uma cópia, não uma
        // referência a uma estrutura de dados interna.
        Object[] elements = c.toArray();

        // Se queremos os elementos em um String[], devemos passar um em
        String [] strings = c.toArray(new String[c.size()]);

        //// Ou podemos passar uma String[] vazia apenas para especificar o tipo e
        //// o método toArray irá alocar um array para nós
        strings = c.toArray(new String[0]);

        

    }
}
