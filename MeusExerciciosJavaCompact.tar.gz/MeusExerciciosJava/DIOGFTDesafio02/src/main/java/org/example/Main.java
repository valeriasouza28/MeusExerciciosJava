package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        String input = scan.nextLine();

        String[] inputSplit = input.split(" ");
        double valor1 = Double.parseDouble(inputSplit[0]);
        double valor2 = Double.parseDouble(inputSplit[1]);

//TODO: Complete os espaços em branco com uma possível solução para o desafio
        double media = Double.parseDouble(String.valueOf(valor1 / valor2));

        System.out.printf("%.2f", media);

        //double test = Double.parseDouble(inputSplit[0] + inputSplit[1]);
        //System.out.println(test);
        //System.out.println(soma);
    }
}