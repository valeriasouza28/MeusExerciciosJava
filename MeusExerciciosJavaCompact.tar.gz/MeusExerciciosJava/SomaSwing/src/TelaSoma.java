import javax.swing.*;

public class TelaSoma {
    private JTextField textField2;
    private JButton button1;
    private JTextField textField1;
    private JTextField textField3;
}
