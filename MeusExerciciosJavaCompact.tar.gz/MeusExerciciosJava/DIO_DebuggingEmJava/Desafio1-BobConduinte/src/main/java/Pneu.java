import java.util.Scanner;

public class Pneu {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int Motorista = scan.nextInt();
        int Maquina = scan. nextInt();

        for(int i = 0;i < Motorista && i < Maquina; i++) {
            if (Motorista > 40 || Maquina > 40) {
                System.out.println("Digite um número inteiro entre 0 e 40!)");
                Motorista = scan.nextInt();
                Maquina = scan.nextInt();
            }

        }
        if (Motorista <= 40 && Maquina <= 40) {
            System.out.println("A diferença é : " + (Motorista - Maquina));

        }


    }
}
