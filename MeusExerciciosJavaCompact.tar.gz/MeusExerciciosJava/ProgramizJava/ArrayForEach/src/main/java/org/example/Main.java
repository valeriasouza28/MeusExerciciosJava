package org.example;

public class Main {
    public static void main(String[] args) {

        //Criar uma array
        int [] age = {12, 4, 5};

        //percorrer a matriz
        // usando for loop each
        System.out.println("Usando loop for-each: \n");
        for (int a : age) {
            System.out.println(a);
        }
    }
}