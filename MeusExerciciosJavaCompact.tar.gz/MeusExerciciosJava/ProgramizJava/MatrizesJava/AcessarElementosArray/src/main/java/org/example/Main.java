package org.example;

public class Main {
    public static void main(String[] args) {

        //Cria uma array
        int[] age = {12, 4, 5, 2, 5};

        //Acessa cada elemento de uma array
        System.out.println("Acessando elementos de um array: \n");
        System.out.println("Primeiro elemento: " + age[0]);
        System.out.println("Segundo elemento: " + age[1]);
        System.out.println("Terceiro elemento: " + age[2]);
        System.out.println("Quarto elemento: " + age[3]);
        System.out.println("Quinto elemento: " + age[4]);
    }
}