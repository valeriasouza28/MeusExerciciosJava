import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class JavaHashMap {

    public static void main(String[] args) {

        //Cria um HashMap
        HashMap<String, Integer> numbers = new HashMap<>();

        System.out.println("Initial HashMap: " + numbers);

        //put() método para adicionr elementos
        numbers.put("Um", 1);
        numbers.put("Dois", 2);
        numbers.put("Tres", 3);

        //Exibe na ordem alfabetica das chaves
        System.out.println("HashMap após o put(): " + numbers);

        //Acessando elementos Hashmap

        HashMap<Integer, String> languages = new HashMap<>();
        languages.put(1, "Java");
        languages.put(2, "Python");
        languages.put(3, "JavaScript");

        //usando o método get() para pegar valor
        String values = languages.get(1);
        //Exibe a chave na ordem numerica
        System.out.println("Valor do index 1: " + values);

        //Retorna a visualização do conjunto de chaves, apenas as chaves do conjunto
        //usando o método KeySet()
        System.out.println("Mostrando chaves usando keySet():" + languages.keySet());

        //Retorna a visualização do conjundo de valores, apenas os valores
        //usando o método values()
        System.out.println("Mostrando valores usando values(): " + languages.values());

        //Retorna a visualização do conjunto par chave/valor
        //usandoo método entrySet()
        System.out.println("Mostrando Chave/Valor do HashMap usando entrySet(): " + languages.entrySet());

        //Alterando o valor do HashMap

        //Mostrando o HashMap Original
        System.out.println("HashMap Original: " + languages);

        //Muda elemento da chave 2, passando o valor da chave e o que vai colocar na chave
       // languages.replace(2, "C++");
        //System.out.println("Alterando chave HashMap usando replace(): " + languages);

        //Removendo os elementos do HashMap

        //Removendo elemento associado a chave 2 uasando o método remove()
        String removeChave = languages.remove(2);
        System.out.println("HashMap atualizada apósremover elemento da chave 2" +  languages);

        /*Aqui, o remove()método só remove a entrada se a chave 2 estiver
        associada ao valor C++ . Como 2 não está associado a C++ , ele não remove a entrada*/
        //languages.remove(2, "C++");

        // iterandoa apenas atrvés das chaves
        System.out.print("Keys: ");
        for (Integer key : languages.keySet()) {
            System.out.print(key);
            //Separando os conjuntos entre sí para a exibição
            System.out.print(", ");
        }

        // iterando apenas através dos valores
        System.out.print("\nValues: ");
        for (String value : languages.values()) {
            System.out.print(value);
            //Separando os conjuntos entre sí para a exibição
            System.out.print(", ");
        }

        // iterando com chave/valor
        System.out.print("\nEntries: ");
        for (Map.Entry<Integer, String> entry : languages.entrySet()) {
            System.out.println(entry);
            //Separando os conjuntos entre sí para a exibição
            System.out.println(", ");
        }

        //Cria um Treemap

        TreeMap<String, Integer> numerosPares = new TreeMap<>();
        numerosPares.put("Dois", 2);
        numerosPares.put("Quatro", 4);
        System.out.println("TreeMap: " + numerosPares);

        //Cria um hashmap de um treemap
        HashMap<String, Integer> numeros = new HashMap<>(numerosPares);
        numeros.put("Tres", 3);
        System.out.println("HashMap: " + numeros);

        //Ao criar um hashmap, podemos incluir parâmetros opcionais: capacidade e fator de carga . Por exemplo,
        HashMap<K, V> numeros = new HashMap(8, 0.6f);
        /*Aqui,

8 (a capacidade é 8) - Isso significa que pode armazenar 8 entradas.
0.6f (fator de carga é 0.6) - Isso significa que sempre que nossa tabela de hash é preenchida em 60%, as entradas são movidas para uma nova tabela de hash com o dobro do tamanho da tabela de hash original.
Se os parâmetros opcionais não forem usados, a capacidade padrão será 16 e o ​​fator de carga padrão será 0,75 .*/


    }

}