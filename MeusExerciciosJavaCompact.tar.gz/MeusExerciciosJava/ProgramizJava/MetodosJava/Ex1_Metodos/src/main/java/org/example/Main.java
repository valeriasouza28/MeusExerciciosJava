package org.example;

public class Main {
    //cria um método
    public int addNumbers(int a, int b){
        int sum = a + b ;
        //retornar valor
        return sum;
    }

    public static void main(String[] args) {

        int num1 = 25;
        int num2 = 15;

        //crie um objeto de Main
        Main obj = new Main();
        //Chamando método
        int result = obj.addNumbers(num1, num2);
        System.out.println("Sum is : " + result);



    }
}