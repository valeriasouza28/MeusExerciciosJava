public class Bicycle {
    private int gear = 5;

    public  void braking(){
        System.out.println("Working of Braking");
    }
}
