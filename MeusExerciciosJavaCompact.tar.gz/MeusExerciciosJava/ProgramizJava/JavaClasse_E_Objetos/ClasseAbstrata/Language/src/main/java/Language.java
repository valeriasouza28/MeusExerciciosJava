abstract class Language {

    //metodo da classe abstrata
    public void display(){
        System.out.println("This is Java Programming");
    }
}

class Main extends Language{

    public static void main(String[] args) {

        //cria um objeto de Main
        Main obj = new Main();

        //acessa método da classe abstrata
        //usando o objeto da classe Main
        obj.display();
    }
}
