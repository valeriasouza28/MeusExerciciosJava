import java.util.*;

public class ExemploOrdenacaoMap {

    /*Dados as informações sobre meus livros favoritos e seus autores.
     * crie  um dicionario e ordene este dicionário:
     * exibindo (Nome Autor - Nome Livros);
     *
     * Autor -- Hawking, Stephen - livro = nome: Uma Breve História do Tempo. páginas: 256
     * Autor = Duhigg,Charles - Livro = Nome O poder do Hábito, páginas : 400
     * Autor = Harari, Yuval Nah - Livro = 21 Lições Para o século 21, páginas; 432*/

    public static void main(String[] args) {

        System.out.println("--\tordem aleatória\t--");
        /* Para fazer isso primeiro criamos uma Livros, criamos
         * um objeto da classe livro.
         * Para exibir em ordem aleatória cria uma hashmap*/
        Map<String, Livro> meusLivros = new HashMap<>() {{

            //Adiciona elementos a Hashmap
            //nome do autor é chave, e como valor a classe Livro que contém o objeto livro como atributos nome do livro e a quantidade de páginas
            put("Hawking, Stephen", new Livro("Uma breve História do tempo", 256));
            put("Duhigg", new Livro("O Poder do Hábito", 408));
            put("Hanari, Yuval Naah", new Livro("Lições para o Século 21", 432));
        }};

        //O método entrySet() para trabalhar com chave e valor separadamente
        for (Map.Entry<String, Livro> livro : meusLivros.entrySet()) {

            /*imprimimos o autor (chave) com o método getKey, e pegamos
             do Livro (valor) apenas o atributo nome com o método getNome()*/
            System.out.println(livro.getKey() + " - " + livro.getValue().getNome());
        }

        System.out.println("--\tExiba Em Ordem de Inserção O Autor Do Livro E O Nome Do Livro\t--");
        /*Para colocar na ordem de inserção usamos um LinkedHashmap*/
        //Cria LinkedHashMap
        Map<String, Livro> meusLivros1 = new LinkedHashMap<>() {{

            //Adiciona elementos a Hashmap
            //nome do autor é chave, e como valor a classe Livro que contém o objeto livro como atributos nome do livro e a quantidade de páginas
            put("Hawking, Stephen", new Livro("Uma breve História do tempo", 256));
            put("Duhigg", new Livro("O Poder do Hábito", 408));
            put("Hanari, Yuval Naah", new Livro("Lições para o Século 21", 432));
        }};

        //O método entrySet() para trabalhar com chave e valor separadamente
        for (Map.Entry<String, Livro> livro : meusLivros1.entrySet()) {

            /*imprimimos o autor (chave) com o método getKey, e pegamos
             do Livro (valor) apenas o atributo nome com o método getNome()*/
            System.out.println(livro.getKey() + " - " + livro.getValue().getNome());}

        System.out.println("--\tExiba Em Ordem Alfabética Os Altores, Exiba o nome do livro\t--");
        //Cria um TreeMap, e passamso como argumento a LinkedHashMap meuslivros1
        Map<String, Livro> meusLivros2 = new TreeMap<>(meusLivros1);
        //E imprimir
        for (Map.Entry<String, Livro> livro : meusLivros2.entrySet()) {
            System.out.println(livro.getKey() + " - " + livro.getValue().getNome());}

        System.out.println("--\tExiba o nome dos livros na ordem alfabética\t--");
        /*Para fazer isso precisamos de um TreeSet para que poder utilizar o comparator,
        * Para utilizar usar o comparator cria uma classe*/
        //Criamos um Set TreeSet,
        Set<Map.Entry<String, Livro>> meusLivros3 = new TreeSet<>(new ComparatorNome());
        meusLivros3.addAll(meusLivros.entrySet());
        for (Map.Entry<String, Livro> livro : meusLivros3) {
            System.out.println(livro.getKey() + " - " + livro.getValue().getNome());
        }





    }
}

//Cria a classe livro
class Livro{

    //Cria atributos
    private String nome;
    private Integer paginas;

    //Usa consrutor para construir o objeto Livro
    public Livro(String nome, Integer paginas) {
        this.nome = nome;
        this.paginas = paginas;
    }

    //Cria getters para fazer a utilização dos atributos privados
    public String getNome() {
        return nome;
    }

    public Integer getPaginas() {
        return paginas;
    }

    //Sobrescreve os métodos equal e hashcode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Livro livro = (Livro) o;
        return nome.equals(livro.nome) && paginas.equals(livro.paginas);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome, paginas);
    }

    //Sobreescreve o métodod toString apara não aparecer enedereço de memória ao invés dos atributos

    @Override
    public String toString() {
        return "Livro{" +
                "nome='" + nome + '\'' +
                ", paginas=" + paginas +
                '}';
    }
}

class ComparatorNome implements Comparator<Map.Entry<String, Livro>>{

    @Override
    public int compare(Map.Entry<String, Livro> l1, Map.Entry<String, Livro> l2) {
        /*Usamos getValue() para pegar o valor da TreeSet, o getNome para pegar o nome  do livro
        * e o o compareToignoreCase e compara com o valor Nome do Livro l1 com l2,*/
        return l1.getValue().getNome().compareToIgnoreCase(l2.getValue().getNome());
    }
}