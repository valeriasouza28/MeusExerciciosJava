package org.example;

public class Main {
    public static void main(String[] args) {

        int [] numeros = {2, -9, 0, 5, 12, -25, 22, 9, 8, 12};
        int soma = 0;
        Double media;

        //Acessa todos os elementos usando for each
        //Adiciona cada elemento em uma soma
        for (int numero : numeros) {
            soma += numero;

        }
        //Pega total dos elementos
        int arrayLenght = numeros.length;

        //Calcula a média
        // Converte a média de inteiro para double
        media = ((double)soma / (double) arrayLenght);
        System.out.println("Soma = " + soma);
        System.out.println("Média = " + media);
    }
}