import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Ex1_AddHashSet {

    public static void main(String[] args) {

        // Criando um HashSet
        Set< String > daysOfWeek =  new HashSet<>();

// Adicionando novos elementos ao HashSet
        daysOfWeek.add( " Segunda- feira " );
        daysOfWeek.add( " terça " );
        daysOfWeek.add( " quarta " );
        daysOfWeek.add( " quinta -feira " );
        daysOfWeek.add( " Sexta " );
        daysOfWeek.add( " Sábado " );
        daysOfWeek.add( " Domingo " );

// Adicionar elementos duplicados será ignorado
        daysOfWeek . add( " Segunda- feira " );

        System .out.println(daysOfWeek);

        //addAll

        //Criando um ArrayList
        List<Integer> list = new ArrayList<>();
        list.add(5);
        list.add(10);
        list.add(15);
        list.add(20);
        list.add(25);

        //Cria ArrayList
        List<Integer> list2 = new ArrayList<>();
        list2.add(3);
        list2.add(6);
        list2.add(9);
        list2.add(12);
        list2.add(15);

        //Cria uma HashSet da coleção  existente ArrayList (list)
        Set<Integer> set = new HashSet<>();

        //Adiciona todos os elementos da coleção existente ArrayList (list2) para a HashSet (set)
        set.addAll(list2);
        //exibe a HashSet set
        System.out.println(set);

        //Hash remove()
        //Remove um elemento de um HshSet (O método remove() retorna false se o elemento não existir no HashSet)

        //Cria um HashSet
        Set<Integer> numbers = new HashSet<>();
        numbers.add(2);
        numbers.add(3);
        numbers.add(4);
        numbers.add(5);
        numbers.add(6);
        numbers.add(7);
        numbers.add(8);
        numbers.add(9);
        numbers.add(10);

        //Exibe a HashSet numbers antes da remoçao
        System.out.println("HashSet numbers Original: " + numbers);

        //Remove o elemento da 10 da HashSet numbers
        boolean isRemoved = numbers.remove(10);
        //Exibe a HashSet numbers após remover o elemento 10
        System.out.println("HashSet numbers após a remoção: " + numbers);

        //removeAll()
        //Remova todos os elmentos pertencentes a um HashSet

        //Cria um ArrayList
        List<Integer> perfectSquare = new ArrayList<>();
        //Adiciona numeros a esta ArrayList que vai ser removido da HashSet numbers
        perfectSquare.add(4);
        perfectSquare.add(9);

        //Usando a HashSet numbers e o método removeAll e passa como parâmetro perfectSquare()
        numbers.removeAll(perfectSquare);
        //Exibe o HashSet numbers após a remoção dos elementos determinados pela ArrayList perfectSquare
        // e removidos pelo método removeAll()
        System.out.println("HashSet numbers após removeAll(): " + numbers);

        //removeIf(Prdicate<? super Integer>filter)
        //Remove todos os elmentos correspondentes a um determinado predicado
        numbers.removeIf(num -> num % 2 == 0);
        System.out.println("Após a remoção com removeIf(): " + numbers);

        //
       



    }

    }

