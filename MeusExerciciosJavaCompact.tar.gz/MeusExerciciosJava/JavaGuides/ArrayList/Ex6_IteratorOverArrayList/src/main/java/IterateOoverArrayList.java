// Java 8 forEach e expressão lambda.
// iterador().
// método iterator() e Java 8 forEachRemaining().
// listaIterator().
// Simples for-each loop.
// loop for com index.

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class IterateOoverArrayList {

    public static void main(String[] args) {

        //Criando um ArrayList de string  uasando
        List<String> fruits = new ArrayList<>();
        // Adicionando novvos elementos para ArrayList
        fruits.add("Banana");
        fruits.add("Apple");
        fruits.add("magno");
        fruits.add("orange");
        fruits.add("Watermelon");
        fruits.add("Strawberry");

        System.out.println("=== Iterar usando Java 8 forEach e lambda ===");
        fruits.forEach(fruit -> {
            System.out.println(fruit);

        });

        System.out.println("\n=== Iterar usando um iterator() ===" );
        Iterator<String> fruitsIterator = fruits.iterator();
        while (fruitsIterator.hasNext()){
            String tvShow = fruitsIterator.next();
            System.out.println(tvShow);
        }


        System.out.println("\n === Iterar usando um iterador() e o método Java 8 forEachRemaining()");
        fruitsIterator = fruits.iterator();
        fruitsIterator.forEachRemaining(fruit ->{
            System.out.println(fruit);
        });

        System.out.println("\n=== Iterar usando  um listIterator() para percorrer em ambas as direções===");
        // Aqui, começamos do final da lista e voltamos para trás
        //O hasPrevious() funciona como o haNext(), só que ao invés de perguntar se há um próximo elemento
        //ele pergunta se há um elemento anterior
        ListIterator<String> listIterator = fruits.listIterator(fruits.size());
        while(listIterator.hasPrevious()){
            //previous() faz referência ao método hasPrevious()
            String fruit = listIterator.previous();
            System.out.println(fruit);
        }

        System.out.println("\n=== Iterar usando um simples loop for-each ===");
        for(String fruit: fruits){
            System.out.println(fruit);
        }

        System.out.println("\n=== Iterar usando loop for com índice===");
        for(int i= 0; i < fruits.size(); i++){
            System.out.println(fruits.get(i));
        }


    }
}
