// Classifica um ArrayList usando o método Collections.sort().
// Classifica um ArrayList usando o método ArrayList.sort().
// Classifica um ArrayList de objetos definidos pelo usuário com um comparador personalizado

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ArrayListSort {
    public ArrayListSort() {
        super();
    }

    public static void main(String[] args) {

        List<String> names = new ArrayList<>();
        names.add("Tony");
        names.add("Tom");
        names.add("Johnson");
        names.add("John");
        names.add("Ramesh");
        names.add("Sanjay");

        System.out.println("Names : " + names);

        // Classifica um ArrayList usando seu método sort(). Você deve passar um
        // Comparator para o método ArrayList.sort().
        names.sort(new Comparator<String>(){
                @Override
                public  int compare(String name1, String name2) {
                    return name1.compareTo(name2);
            }
        });

        // A chamada do método `sort()` acima também pode ser escrita simplesmente usando a expressão lambda
        names.sort((name1, name2) -> name1.compareTo(name2));

        // Segue uma solução ainda mais concisa
        names.sort(Comparator.naturalOrder());
        System.out.println("Sorted Names : " + names);

    }

}
