// Verifica se um ArrayList contém um determinado elemento | contém()

// Localiza o índice da primeira ocorrência de um elemento em um ArrayList | índice de()

// Localiza o índice da última ocorrência de um elemento em um ArrayList | lastIndexOf()

import java.util.ArrayList;
import java.util.List;

public class Ex7_SearchElementsArrayList {

    public static void main(String[] args) {

        //Criando um ArrayList de String usando
        List<String> fruits = new ArrayList<>();
        fruits.add("Banana");
        fruits.add("Apple");
        fruits.add("Orange");
        fruits.add("Mango");
        fruits.add("Watermelon");
        fruits.add("Strawberry");

        //Verifica se um ArrayList contém um determinado elemento
        System.out.println("O array de nome comtém \"Mango\": " + fruits.contains("Mango"));

        // Encontra o índice da primeira ocorrência de um elemento em um ArrayList, retorna a posição da ocorrência  do elemento
        System.out.println("indexOf \"Banana\": " + fruits.indexOf("Banana"));
        System.out.println("indexOf \"Apple\": " + fruits.indexOf("Apple"));

        // Encontra o índice da última ocorrência de um elemento em um ArrayList
        System.out.println("lastIndexOf \"Watermelon\" : " + fruits.lastIndexOf("Watermelon"));
        System.out.println("lastIndexOf \"Strawberry\" : " + fruits.lastIndexOf("Strawberry"));

    }
}
