//Como criar uma ArrayList de outra coleção usando o construtor
//ArrayList(Collection c).

//Como adicionar todos os elementos de uma coleção existente ao novo
//ArrayList usando método addAll().

import java.util.ArrayList;
import java.util.List;

public class Ex3_ArrayListCollection {
    public static void main(String[] args) {



        //Cria uma ArrayList
        List<Integer> firstFivePrimeNumbers = new ArrayList<>();

        firstFivePrimeNumbers.add(2);
        firstFivePrimeNumbers.add(3);
        firstFivePrimeNumbers.add(5);
        firstFivePrimeNumbers.add(7);
        firstFivePrimeNumbers.add(11);

        //Criando ArrayList de otra coleção

        List<Integer> firstTenPrimeNumbers = new ArrayList<>(firstFivePrimeNumbers);

        List<Integer> nextFivePrimeNumbers = new ArrayList<>();
        nextFivePrimeNumbers.add(13);
        nextFivePrimeNumbers.add(17);
        nextFivePrimeNumbers.add(19);
        nextFivePrimeNumbers.add(23);
        nextFivePrimeNumbers.add(29);

        //Adicionado uma coleção inteira a um ArrayList
        firstTenPrimeNumbers.addAll(nextFivePrimeNumbers);

        System.out.println(firstTenPrimeNumbers);



    }



}
