import java.util.ArrayList;
import java.util.List;

//Como verificar se uma ArrayList está vazio usando o método isEmpty()
//Como encontrar o tamanho de uma ArrayList usando o método size().
//Como acessar o elemento em um indice especifico em um arrayList uasndo um mmétodo get()
//Como modificar um elemento especifico em um index ArrayList usando método se()
public class AccessElementsArrayList {

    public static void main(String[] args) {

        List<String> topProgrammingLanguages = new ArrayList<>();

        //Checa se um ArrayList está vazio
        System.out.println("A lista topProgrammingLanguages está vazia? : " + topProgrammingLanguages.isEmpty());

        topProgrammingLanguages.add("C");
        topProgrammingLanguages.add("Java");
        topProgrammingLanguages.add("C++");
        topProgrammingLanguages.add("Python");
        topProgrammingLanguages.add(".net");

        //Ache o taamanho de um ArrayList passando o nome da ArrayList co o método size()
        System.out.println("Aqui estão as tops " + topProgrammingLanguages.size() + " Linguagens de Programação no mundo");
        System.out.println(topProgrammingLanguages);

        //Recupera elemento de um daddo index
        //Usa o método get para pegar a String (java) da lista que está na posição 1
        String bestProgrammingLang = topProgrammingLanguages.get(1);
        //Usa o método get para pegar a String (java) da lista que está na posição 1
        String secondBestProgrammingLang = topProgrammingLanguages.get(1);
        //Usa o método get para pegar o tamanho da ArrayList e exibir a String (.net) da lista que está na posição -1
        String dotNetrogrammingLang = topProgrammingLanguages.get(topProgrammingLanguages.size() - 1);

        System.out.println("\nMelhor liguagem de programação: " + bestProgrammingLang);
        System.out.println("Segunda melhor linguagem de programação: " + secondBestProgrammingLang);
        System.out.println("Dot Net Linguagem Programação: " + dotNetrogrammingLang);

        //modifica o elemento do index 4 (.net) para (C#)
        topProgrammingLanguages.set(4, "C#");
        System.out.println("List das principais liguagem de programação modificadas: " + topProgrammingLanguages);




    }


}
