/*
* Programa para remover elementos de uma ArrayList
*
* */

import java.util.ArrayList;
import java.util.List;

public class RemoveElementsArrayList {

    public static void main(String[] args) {

        //Criando uma ArrayList de String usando
        List<String> fruits = new ArrayList<>();
        //Adicionando novos elementos para o ArrayList
        fruits.add("Banana");
        fruits.add("Apple");
        fruits.add("Mango");
        fruits.add("Orange");
        fruits.add("Pineapple");
        fruits.add("Grapes");

        System.out.println(fruits);

        //Remove o elemento do index '5'
        fruits.remove(5);
        System.out.println("Após remove(5): " + fruits);

        // Remove a primeira ocorrência do elemento fornecido da ArrayList
        // (O método remove() retorna false se o elemento não existir no
        // Lista de Matriz)
        boolean isRemoved = fruits.remove("Mango");
        System.out.println("Após remover Mango: " + fruits);

        //Remove todos os elmentos que existem dentro da coleção
        List<String> subfruitsList = new ArrayList<>();
        //Adiciona elementos a subfruitsList
        subfruitsList.add("Apple");
        subfruitsList.add("Banana");
        System.out.println("Exibe a subfruitsList após criar e add elementos: " + subfruitsList);

        /*Criamos uma ArrayList subfruitsList e adicionamos Dentro dela elementos que queremos remover da
        ArrayList fruits onde adiciconamos "Apple" "Banana" então temos uma ArrayList com esses dois elementos,
         para excluir os ellementos da ArrayList fruits, colocamos fruits(POnto) o método removeAll e passamos  como parâmetro
         a ArrayList subfruits*/
        fruits.removeAll(subfruitsList);
        System.out.println("Após removeAll(subfruitsList): " + fruits);

        //Remove todos os elementos da ArrayList
        fruits.clear();
        System.out.println("Após clear(): " + fruits);

        System.out.println("Exibe Lista de elementos excluidos da ArrayList (fruits): " + subfruitsList);




    }
}
