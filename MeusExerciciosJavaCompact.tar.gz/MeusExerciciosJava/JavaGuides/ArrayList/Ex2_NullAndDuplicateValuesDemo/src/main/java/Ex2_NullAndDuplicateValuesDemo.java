import java.util.ArrayList;
import java.util.List;

public class Ex2_NullAndDuplicateValuesDemo {

    public static void main(String[] args) {

        nullValueDemo();
        duplicateValueDemo();


    }


    //Fima da classe principal
    private static void nullValueDemo() {

        List<String> list = new ArrayList<>();
        list.add(null);
        list.add(null);

        System.out.println(list.toString());
    }

    private static void duplicateValueDemo() {

        List<String> list = new ArrayList<>();

        list.add("duplicate");
        list.add("duplicate");

        System.out.println(list.toString());
    }
}