import java.util.ArrayList;
import java.util.List;

//Como criar um ArrayList uasndo o construtor ArrayList()
//Adiciona elementos para um ArrayList usando métodod add()
public class CreateArrayListExamplo {

    public static void main(String[] args) {

        //Criando uma ArrayList usando String
        List<String> fruits = new ArrayList<>();

        //Adicionando elementos a ArrayList
        fruits.add("Banana");
        fruits.add("Apple");
        fruits.add("mango");
        fruits.add("orange");

        //Exibindo ArrayList após dicionar elementos
        System.out.println(fruits);








    }
}
