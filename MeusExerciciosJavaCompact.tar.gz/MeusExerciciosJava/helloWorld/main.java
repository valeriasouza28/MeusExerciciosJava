class main {
    public static void main(String[]args){
        String nome;
        nome = "Let's Code";
        nome = "Jessé";
        nome = "Brasil";
        Sistem.out.println("Olá, " + nome);
    }
}
