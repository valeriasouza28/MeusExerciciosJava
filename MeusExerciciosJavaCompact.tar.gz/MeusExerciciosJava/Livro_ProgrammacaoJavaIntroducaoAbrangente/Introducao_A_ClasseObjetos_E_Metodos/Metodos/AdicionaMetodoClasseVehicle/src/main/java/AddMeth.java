
    class AddMeth {
    
        public static void main(String[] args) {

            //Cria objeto da minivan da classe Vehicle
            Vehicle minivan = new Vehicle();
            //Cria objeto da minivan da classe Vehicle
            Vehicle sportscar = new Vehicle();

            //Atribui as variáveis do tipo int range1 e range2
            int range1, range2;

// atribui valores a campos de minivan
            minivan.passengers = 7;
            minivan.fuelCap = 16;
            minivan.mpg = 21;

// atribui valores a campos de sportscar
            sportscar.passengers = 2;
            sportscar.fuelCap = 14;
            sportscar.mpg = 12;

            //Exibe números de passageiros de uma minivan
            System.out.print("Minivan can carry " + minivan.passengers + ". ");
            minivan.range(); // exibe a autonomia de minivan

            //exibe número de passageiros de um sportcar
            System.out.print("Sportscar can carry " + sportscar.passengers + ". ");
            sportscar.range(); // exibe a autonomia de sportscar.
        }
    }


    // Adiciona range a Vehicle.
    class Vehicle {

       //Atributos qde veiculos que definem sua autonomia
        int fuelCap; // capacidade de armazenamento de combustível em galões
        int passengers; // número de passageiros
        int mpg; // consumo de combustível em milhas por galão


        // Exibe a autonomia.

        /*Essa linha declara um método chamado range() que não  tem parâmetros. Seu tipo de retorno é void.
         Logo range() não retorna nenhum valor para o chamado*/
        void range() { // O método range está contido na classe Vehicle.
            System.out.println("Range is " + fuelCap * mpg);
        }
    }

