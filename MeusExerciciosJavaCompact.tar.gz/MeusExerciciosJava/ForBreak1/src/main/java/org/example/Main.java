package org.example;

public class Main {
    public static void main(String[] args) {
        for (int i = x; i < y; i++) {
            if (i % 19 == 0 {
                System.out.println("Achei um número divisível por 19 entre x e y");
                break;
            }
        }
    }
}