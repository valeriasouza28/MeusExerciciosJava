public class GradeBook {

    public void dysplayMensenger(String courseName){

        System.out.print("Welcome to the Grade Book for \n%s!\n", courseName);

    }
}
