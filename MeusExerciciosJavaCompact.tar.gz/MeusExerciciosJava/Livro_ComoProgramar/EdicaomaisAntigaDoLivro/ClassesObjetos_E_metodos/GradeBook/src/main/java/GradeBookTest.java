import java.util.Scanner;

public class GradeBookTest {

    public static void main(String[] args) {

        Scanner input = new Scanner (System.in);
        GradeBook MyGradeBook = new GradeBook();
        System.out.println("Please enter the course name: ");
        String nameOfCourse = input.nextLine();
        System.out.println();
        MyGradeBook.dysplayMensenger(nameOfCourse);
    }
}
