import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class CollectionTest {

    public static void main(String[] args) {

        //adiona elementos no array colors a listar
        String[] colors = {"Mangenta", "Red", "White", "Blue", "CYAN"};
        List<String> list = new ArrayList<String>();

        for (String color: colors)
            list.add(color); //adiciona a  cor ao fim da lista

        // adiciona elementos no array removeColors em removeList
        String[] removeColors = {"Red", "White", "Blue"};
        List<String> removeList = new ArrayList<String>();

        for (String color : removeColors)
            removeList.add(color);

        //Gera saída do conteúdo da lista
        System.out.println("Array List: " );

        for (int count = 0; count < list.size(); count++)
            System.out.printf("%s ", list.get(count));

        // remove da lista as cores contidas na removeList
        removeColors(list, removeList);

        //gera saida do conteudo da lista
        System.out.println("\n\nArrayList after calling removeColors: ");

        for (String color : list)
            System.out.printf("%s ", color);
    }//fim de main

    //remove cores especificadas em collections2 a partir de collectio1
    private static void removeColors(Collection<String> collection1, Collection<String> collection2){
        Iterator<String> iterator = collection1.iterator();

        //loop enquanto a coleção tiver itens
        while(iterator.hasNext()){

            if(collection2.contains(iterator.next()))
                iterator.remove();//remove color atual
        }//fim do while
    }//fim do método remove colors

}//Fim da classe CollectionTest
