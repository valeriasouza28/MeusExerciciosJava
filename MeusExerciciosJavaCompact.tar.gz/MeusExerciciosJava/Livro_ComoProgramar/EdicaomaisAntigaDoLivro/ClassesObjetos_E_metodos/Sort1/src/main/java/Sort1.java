import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Sort1 {

    public static void main(String[] args) {

        String[] suits = {"Hears", "Diamonds", "Clubs", "Speads"};

        //cria e exibe uma lista que contém os elementos do array de ternos
        List<String> list = Arrays.asList(suits); //cria List
        System.out.printf("Unsorted array elements: %s\n", list);

        Collections.sort(list); //classifica ArrayList

        //gera a saida da lista
        System.out.printf("Sorted array elements: %s\n", list);

        //classifica na ordem decrescente utilizando um comparador
        Collections.sort(list, Collections.reverseOrder());
        //gera saida da  lista na ordem decrescente
        System.out.printf("Reverse Order: %s\n", list);

    }//fim da main
}//fim da classe Sort1
