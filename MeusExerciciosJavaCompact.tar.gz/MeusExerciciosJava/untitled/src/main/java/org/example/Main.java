package org.example;

public class Main {
    public static void main(String[] args) {

        boolean fimDeSemana = false;
        boolean fazendoSol = true;
        boolean vamosAPraia = fimDeSemana && fazendoSol;

        //Tabela verdade
        //Operador && (AND)
        //true && true = true
        //true && false = false
        //false && true = false
        //false && false = false

        //operador || (or) esse se simbolo pode ser chamado de pipe
        //true || true = true
        //true || false = true
        //false || true = true
        //false || false = false

        System.out.println(vamosAPraia);

        String mensagem = fimDeSemana ? "É fim de semana!" : "Não é fim de semana";
        System.out.println(mensagem);


    }
}