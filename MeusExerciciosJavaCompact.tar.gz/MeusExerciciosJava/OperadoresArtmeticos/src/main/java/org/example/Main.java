package org.example;

public class Main {
    public static void main(String[] args) {

        int n1 = 3;
        int n2 = 5;
        float m = n1 + n2 /2;
        //System.out.println("A média é igual a " + m);
        int i = 3;
        int expressao = 10 - 5 * 2 + --i;
        System.out.println(expressao);
    }
}